import * as THREE from 'three';
import { OrbitControls } from './libs/OrbitControls.js';

/* ================= 基础场景 ================= */
const stageEl = document.getElementById('stage');
const canvas = document.getElementById('scene');

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;

/* ================= 聚焦虚化（在 WebGL 内完成）=================
   单画布，避免「双 WebGL 上下文 + CSS 模糊逐帧重算」带来的卡顿与残留。
   流程：整场渲染 → rtSharp → 横向模糊 → 纵向模糊 → 合成
        （清晰图与虚化图按 uFocus 混合）→ 最后把选中部件单独清晰地画在最上层
   =========================================================== */
const rtSharp = new THREE.WebGLRenderTarget(2, 2, {
  minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, stencilBuffer: false,
});
const rtBlurA = new THREE.WebGLRenderTarget(2, 2, {
  minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, stencilBuffer: false,
});
const rtBlurB = new THREE.WebGLRenderTarget(2, 2, {
  minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, stencilBuffer: false,
});
rtSharp.texture.colorSpace = THREE.NoColorSpace;
rtBlurA.texture.colorSpace = THREE.NoColorSpace;
rtBlurB.texture.colorSpace = THREE.NoColorSpace;

const QUAD_VS = `
  varying vec2 vUv;
  void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

/* 9 抽样高斯模糊，在二分之一分辨率上做，开销很小 */
function makeBlurMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {
      tDiffuse: { value: null },
      uDir: { value: new THREE.Vector2(1, 0) },
      uRadius: { value: 2.2 },
    },
    vertexShader: QUAD_VS,
    fragmentShader: `
      uniform sampler2D tDiffuse;
      uniform vec2 uDir;
      uniform float uRadius;
      varying vec2 vUv;
      void main() {
        vec2 d = uDir * uRadius;
        vec4 s = texture2D(tDiffuse, vUv) * 0.1633;
        s += texture2D(tDiffuse, vUv - d * 1.0) * 0.1531;
        s += texture2D(tDiffuse, vUv + d * 1.0) * 0.1531;
        s += texture2D(tDiffuse, vUv - d * 2.0) * 0.12245;
        s += texture2D(tDiffuse, vUv + d * 2.0) * 0.12245;
        s += texture2D(tDiffuse, vUv - d * 3.0) * 0.0918;
        s += texture2D(tDiffuse, vUv + d * 3.0) * 0.0918;
        s += texture2D(tDiffuse, vUv - d * 4.0) * 0.051;
        s += texture2D(tDiffuse, vUv + d * 4.0) * 0.051;
        gl_FragColor = s;
      }
    `,
    depthTest: false, depthWrite: false,
  });
}
const blurMatH = makeBlurMaterial();
const blurMatV = makeBlurMaterial();

const compositeMat = new THREE.ShaderMaterial({
  uniforms: {
    tSharp: { value: rtSharp.texture },
    tBlur: { value: rtBlurB.texture },
    uFocus: { value: 0 },
    uVeil: { value: new THREE.Color(0.976, 0.984, 1.0) },
  },
  vertexShader: QUAD_VS,
  fragmentShader: `
    uniform sampler2D tSharp;
    uniform sampler2D tBlur;
    uniform float uFocus;
    uniform vec3 uVeil;
    varying vec2 vUv;
    void main() {
      vec3 sharp = texture2D(tSharp, vUv).rgb;
      vec3 soft  = texture2D(tBlur, vUv).rgb;
      vec3 c = mix(sharp, soft, uFocus);
      float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
      c = mix(vec3(l), c, mix(1.0, 0.8, uFocus));          // 虚化时轻微降饱和
      c = mix(c, uVeil, 0.26 * uFocus);                    // 叠一层薄纱，压住背景
      gl_FragColor = vec4(c, 1.0);
      #include <colorspace_fragment>
    }
  `,
  depthTest: false, depthWrite: false,
});

const quadScene = new THREE.Scene();
const quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
const quadMesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), blurMatH);
quadMesh.frustumCulled = false;
quadScene.add(quadMesh);

let blurAmount = 0;   // 0 = 全清晰，1 = 全虚化
let blurTarget = 0;

const scene = new THREE.Scene();

/* 背景：自上而下的柔和渐变（浅色 = 白到浅灰；深色 = 石墨到近黑） */
function makeBackgroundTexture(dark) {
  const c = document.createElement('canvas');
  c.width = 8; c.height = 256;
  const g = c.getContext('2d');
  const grd = g.createLinearGradient(0, 0, 0, 256);
  if (dark) {
    grd.addColorStop(0, '#1a2027');
    grd.addColorStop(0.55, '#12171c');
    grd.addColorStop(1, '#0a0d10');
  } else {
    grd.addColorStop(0, '#ffffff');
    grd.addColorStop(0.55, '#f8fafc');
    grd.addColorStop(1, '#e7ebf0');
  }
  g.fillStyle = grd; g.fillRect(0, 0, 8, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
scene.background = makeBackgroundTexture(false);
scene.fog = new THREE.Fog(0xeef1f5, 8.5, 19);

const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.05, 60);
camera.position.set(3.8, 2.6, 4.4);

const controls = new OrbitControls(camera, stageEl);
controls.enableDamping = true;
controls.dampingFactor = 0.07;
controls.maxPolarAngle = 1.56;
controls.minDistance = 0.5;
controls.maxDistance = 8;

/* 灯光：棚拍布光——主光造型、辅光压暗部、轮廓光勾边 */
const ambient = new THREE.AmbientLight(0xffffff, 0.6);
const hemi = new THREE.HemisphereLight(0xffffff, 0xd9dee5, 0.55);
scene.add(ambient, hemi);

const dirLight = new THREE.DirectionalLight(0xffffff, 2.0);
dirLight.position.set(2.9, 4.4, 2.4);
dirLight.castShadow = true;
dirLight.shadow.mapSize.set(2048, 2048);
dirLight.shadow.camera.left = -2.6;
dirLight.shadow.camera.right = 2.6;
dirLight.shadow.camera.top = 2.6;
dirLight.shadow.camera.bottom = -2.6;
dirLight.shadow.bias = -0.0004;
dirLight.shadow.normalBias = 0.02;
scene.add(dirLight);

const fillLight = new THREE.DirectionalLight(0xe9eff8, 0.55);
fillLight.position.set(-3.2, 2.4, 1.7);
scene.add(fillLight);

const rimLight = new THREE.DirectionalLight(0xffffff, 0.5);
rimLight.position.set(-1.4, 2.6, -3.6);
scene.add(rimLight);

/* 极淡的冷暖补光，给金属面一点色彩分离 */
const accentLight = new THREE.PointLight(0xd2e2ff, 0.5, 8, 2);
accentLight.position.set(-2.2, 1.9, 1.9);
scene.add(accentLight);
const accentLight2 = new THREE.PointLight(0xffe4c8, 0.35, 7, 2);
accentLight2.position.set(2.1, 1.4, -2.3);
scene.add(accentLight2);

/* 聚焦时会在 layer 1 上单独重画选中的部件；灯光必须同时属于该层，
   否则那一遍渲染没有光源，部件会变成全黑剪影。 */
for (const l of [ambient, hemi, dirLight, fillLight, rimLight, accentLight, accentLight2]) {
  l.layers.enable(1);
}

/* ================= 环境反射（IBL）=================
   只有直射光时，金属面（铝型材、钢板、喷塑件）没有可反射的东西，
   会发灰发死、高光只剩一个小点。这里用一组自发光面片搭一个「棚拍灯箱」，
   经 PMREM 烘成环境贴图挂到 scene.environment，
   金属件就有了正确的反射层次、渐变高光与色彩分离，接近产品渲染图。
   ================================================ */
function makeStudioEnv(dark) {
  const s = new THREE.Scene();
  const panel = (hex, sx, sy, sz, x, y, z) => {
    const m = new THREE.Mesh(
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshBasicMaterial({ color: hex })
    );
    m.scale.set(sx, sy, sz);
    m.position.set(x, y, z);
    s.add(m);
  };
  /* 灯箱内壁 */
  const room = new THREE.Mesh(
    new THREE.BoxGeometry(9, 9, 9),
    new THREE.MeshBasicMaterial({ color: dark ? 0x1a2028 : 0xdde4ec, side: THREE.BackSide })
  );
  s.add(room);
  /* 顶部主柔光箱：决定金属面那道长条高光 */
  panel(0xffffff, 5.0, 0.1, 5.0, 0, 3.3, 0);
  /* 前上方补光：让正面板有从上到下的明暗过渡 */
  panel(dark ? 0xd6e4ff : 0xf6f9ff, 4.4, 0.1, 2.6, 0.4, 2.15, 3.2);
  /* 左冷右暖两条光带：给金属面一点色彩分离，避免整体发灰 */
  panel(0xbed8ff, 0.1, 2.6, 4.4, -3.9, 0.8, 0.2);
  panel(0xffe6c8, 0.1, 2.2, 3.4, 3.9, 0.7, -0.4);
  /* 地面：浅色主题给一层浅灰地板反射，深色主题压暗，保住机身厚度 */
  panel(dark ? 0x0b0f14 : 0x98a4b1, 8, 0.1, 8, 0, -1.7, 0);
  return s;
}
const pmrem = new THREE.PMREMGenerator(renderer);
const envLight = pmrem.fromScene(makeStudioEnv(false), 0.03).texture;
const envDark = pmrem.fromScene(makeStudioEnv(true), 0.03).texture;
pmrem.dispose();
scene.environment = envLight;

/* 地面 */
const floorMat = new THREE.MeshStandardMaterial({ color: 0xe9edf2, roughness: 0.94, metalness: 0, envMapIntensity: 0.35 });
const floor = new THREE.Mesh(
  new THREE.CircleGeometry(5.5, 64).rotateX(-Math.PI / 2),
  floorMat
);
floor.receiveShadow = true;
scene.add(floor);

/* 落地阴影（环境光遮蔽），让设备稳稳压在地面上 */
function makeShadowTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  const rg = g.createRadialGradient(128, 128, 8, 128, 128, 126);
  rg.addColorStop(0, 'rgba(18,24,32,.40)');
  rg.addColorStop(0.45, 'rgba(18,24,32,.15)');
  rg.addColorStop(1, 'rgba(18,24,32,0)');
  g.fillStyle = rg; g.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
const aoDisc = new THREE.Mesh(
  new THREE.PlaneGeometry(2.2, 1.75).rotateX(-Math.PI / 2),
  new THREE.MeshBasicMaterial({ map: makeShadowTexture(), transparent: true, depthWrite: false })
);
aoDisc.position.y = 0.002;
scene.add(aoDisc);

const grid = new THREE.GridHelper(12, 60, 0xbcc6d2, 0xd8dee6);
grid.material.transparent = true;
grid.material.opacity = 0.8;
grid.position.y = 0.004;
scene.add(grid);

/* ================= 主题（浅色 / 深色）=================
   深色模式面向大屏投影：背景压暗、轮廓光加强，机器本体从背景里"跳"出来。
   ==================================================== */
let isDark = false;
function applyTheme(dark) {
  isDark = dark;
  document.body.classList.toggle('dark', dark);

  const prevBg = scene.background;
  scene.background = makeBackgroundTexture(dark);
  if (prevBg && prevBg.dispose) prevBg.dispose();
  scene.fog.color.setHex(dark ? 0x12171c : 0xeef1f5);
  floorMat.color.setHex(dark ? 0x1b2128 : 0xe9edf2);
  grid.material.color.setHex(dark ? 0x39434e : 0xbcc6d2);
  grid.material.opacity = dark ? 0.6 : 0.8;

  ambient.intensity = dark ? 0.22 : 0.3;
  hemi.intensity = dark ? 0.24 : 0.32;
  dirLight.intensity = dark ? 1.55 : 1.75;
  fillLight.intensity = dark ? 0.32 : 0.42;
  rimLight.intensity = dark ? 0.95 : 0.5;
  accentLight.intensity = dark ? 0.75 : 0.5;

  /* 环境贴图决定金属面的反射底子，两种主题各用一套灯箱 */
  scene.environment = dark ? envDark : envLight;

  compositeMat.uniforms.uVeil.value.setRGB(
    ...(dark ? [0.075, 0.086, 0.10] : [0.976, 0.984, 1.0])
  );
}

/* ================= 工具 ================= */
const D2R = Math.PI / 180;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
function box(w, h, d, mat) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
  m.castShadow = true; m.receiveShadow = true;
  return m;
}
function cyl(rt, rb, h, mat, seg = 24) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), mat);
  m.castShadow = true; m.receiveShadow = true;
  return m;
}

/* 常用材质（浅色主题下整体提亮，保留图纸要求的亚光黑机身）
   envMapIntensity：环境反射强度——金属件给足，让高光有形状；
   吸光的橡胶、深色喷塑面压低，避免整个机身被环境光洗白 */
const M = {
  alu:     new THREE.MeshStandardMaterial({ color: 0xaeb8c3, metalness: 0.78, roughness: 0.32, envMapIntensity: 0.95 }),
  aluDark: new THREE.MeshStandardMaterial({ color: 0x6b7681, metalness: 0.75, roughness: 0.42, envMapIntensity: 0.8 }),
  frame:   new THREE.MeshStandardMaterial({ color: 0x333b45, metalness: 0.62, roughness: 0.42, envMapIntensity: 0.7 }),
  base:    new THREE.MeshStandardMaterial({ color: 0x1c222b, metalness: 0.55, roughness: 0.55, envMapIntensity: 0.55 }),
  panel:   new THREE.MeshStandardMaterial({ color: 0x232b34, metalness: 0.48, roughness: 0.6, envMapIntensity: 0.5 }),
  slot:    new THREE.MeshStandardMaterial({ color: 0x8d98a4, metalness: 0.6, roughness: 0.45, envMapIntensity: 0.85 }),
  armBody: new THREE.MeshStandardMaterial({ color: 0x363e47, metalness: 0.68, roughness: 0.36, envMapIntensity: 0.8 }),
  armAcc:  new THREE.MeshStandardMaterial({ color: 0xef8a24, metalness: 0.5, roughness: 0.4, envMapIntensity: 0.6 }),
  pcb:     new THREE.MeshStandardMaterial({ color: 0x1a7a4a, metalness: 0.3, roughness: 0.55, envMapIntensity: 0.5 }),
  chip:    new THREE.MeshStandardMaterial({ color: 0x14181e, metalness: 0.45, roughness: 0.45, envMapIntensity: 0.55 }),
  silver:  new THREE.MeshStandardMaterial({ color: 0xc4ccd5, metalness: 0.88, roughness: 0.28, envMapIntensity: 1.0 }),
  rubber:  new THREE.MeshStandardMaterial({ color: 0x14181c, metalness: 0.08, roughness: 0.92, envMapIntensity: 0.35 }),
  ball:    new THREE.MeshStandardMaterial({ color: 0xc9382c, metalness: 0.12, roughness: 0.32, envMapIntensity: 0.7 }),
};

/* 主题点缀色（浅色背景下使用深蓝，保证在白底上的对比度） */
const ACCENT = 0x1f56d6;
const ACCENT2 = 0x34d399;

/* 网孔板贴图（冲孔外观） */
function makeHoleTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  g.fillStyle = '#252c35'; g.fillRect(0, 0, 256, 256);
  for (let y = 16; y < 256; y += 32) {
    for (let x = 16; x < 256; x += 32) {
      g.beginPath(); g.arc(x, y, 5, 0, Math.PI * 2);
      g.fillStyle = '#0e1319'; g.fill();
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(4, 3);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/* 机身铭牌贴图（浅铝底 + 深色字） */
function makeNameplateTexture() {
  const c = document.createElement('canvas');
  c.width = 512; c.height = 192;
  const g = c.getContext('2d');
  const grd = g.createLinearGradient(0, 0, 512, 192);
  grd.addColorStop(0, '#eef1f5');
  grd.addColorStop(0.55, '#dde3e9');
  grd.addColorStop(1, '#c2c9d2');
  g.fillStyle = grd; g.fillRect(0, 0, 512, 192);
  g.fillStyle = '#161b21';
  g.font = 'bold 64px "Microsoft YaHei",sans-serif';
  g.fillText('YL-293H', 26, 76);
  g.fillStyle = '#2c343d';
  g.font = '30px "Microsoft YaHei",sans-serif';
  g.fillText('人工智能综合实验箱', 26, 122);
  g.fillStyle = '#4d565f';
  g.font = '23px Consolas,monospace';
  g.fillText('SN 2026-0001   AC220V 50Hz', 26, 162);
  g.strokeStyle = 'rgba(28,34,42,.5)'; g.lineWidth = 4;
  g.strokeRect(2, 2, 508, 188);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/* ================= 整机建模 ================= */
const TABLE_TOP = 0.765;          // 台面高度
const parts = {};                // 部件注册表
const clickableGroups = [];
const glowState = {};

function registerPart(id, group, info) {
  group.userData.partId = id;
  const meshes = [];
  group.traverse(o => {
    if (o.isMesh) {
      o.material = o.material.clone();
      o.userData.origEmissive = o.material.emissive ? o.material.emissive.getHex() : null;
      o.userData.origEI = o.material.emissiveIntensity;
      meshes.push(o);
    }
  });
  parts[id] = { group, meshes, info };
  clickableGroups.push(group);
  glowState[id] = 0;
}

/* ---- 结构件：底柜 + 台面 + 围框 ---- */
const frameGroup = new THREE.Group();
{
  // 福马轮
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const caster = new THREE.Group();
    const body = cyl(0.05, 0.05, 0.06, M.rubber); body.position.y = 0.05;
    const wheel = cyl(0.046, 0.046, 0.024, M.rubber); wheel.rotation.z = Math.PI / 2; wheel.position.y = 0.045;
    caster.add(body, wheel);
    caster.position.set(sx * 0.5, 0, sz * 0.3);
    frameGroup.add(caster);
  }
  // 底裙 + 柜体
  const skirt = box(1.22, 0.1, 0.8, M.base); skirt.position.set(0, 0.1, 0);
  const body = box(1.16, 0.56, 0.74, M.panel); body.position.set(0, 0.43, 0);
  frameGroup.add(skirt, body);
  // 前面板（左右两块，中间露出控制柜）
  const fl = box(0.42, 0.44, 0.02, M.frame); fl.position.set(-0.37, 0.5, 0.375);
  const fr = box(0.42, 0.44, 0.02, M.frame); fr.position.set(0.37, 0.5, 0.375);
  frameGroup.add(fl, fr);
  /* 折边高光：钣金折弯处的亮边，让面板不再是"一块死黑"，
     顺带把面板轮廓勾出来（真实产品渲染里最容易看出质感的就是这条边） */
  for (const sx of [-1, 1]) {
    const eTop = box(0.42, 0.012, 0.026, M.aluDark); eTop.position.set(sx * 0.37, 0.716, 0.375);
    const eIn  = box(0.012, 0.44, 0.026, M.aluDark); eIn.position.set(sx * 0.165, 0.5, 0.375);
    const eOut = box(0.012, 0.44, 0.026, M.aluDark); eOut.position.set(sx * 0.575, 0.5, 0.375);
    frameGroup.add(eTop, eIn, eOut);
  }
  /* 机身铭牌（铝牌 + 型号/序列号），拿图纸编号对得上 */
  const plate = box(0.15, 0.056, 0.004, new THREE.MeshStandardMaterial({
    map: makeNameplateTexture(), metalness: 0.35, roughness: 0.42, envMapIntensity: 0.6,
  }));
  plate.position.set(-0.37, 0.61, 0.388);
  frameGroup.add(plate);
  /* 面板紧固螺钉（钣金件的可见紧固点） */
  for (const sx of [-1, 1]) for (const dx of [-1, 1]) for (const dy of [1, -1]) {
    const s = cyl(0.0055, 0.0055, 0.006, M.aluDark, 10);
    s.rotation.x = Math.PI / 2;
    s.position.set(sx * 0.37 + dx * 0.185, 0.5 + dy * 0.195, 0.386);
    frameGroup.add(s);
  }
  // 型材台面 + 安装槽
  const top = box(1.2, 0.03, 0.8, M.alu); top.position.set(0, 0.75, 0);
  frameGroup.add(top);
  for (let k = 0; k < 14; k++) {
    const g = box(0.006, 0.032, 0.78, M.slot);
    g.position.set(-0.52 + k * 0.08, 0.765, 0);
    frameGroup.add(g);
  }
  // 四角立柱
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const p = box(0.05, 0.8, 0.05, M.frame);
    p.position.set(sx * 0.575, 1.165, sz * 0.375);
    frameGroup.add(p);
  }
  // 顶部横梁
  for (const sz of [-1, 1]) {
    const b = box(1.1, 0.045, 0.045, M.frame); b.position.set(0, 1.545, sz * 0.375);
    frameGroup.add(b);
  }
  for (const sx of [-1, 1]) {
    const b = box(0.045, 0.045, 0.66, M.frame); b.position.set(sx * 0.575, 1.545, 0);
    frameGroup.add(b);
  }
  // 中部立柱与横梁
  for (const sx of [-0.29, 0.29]) {
    const p = box(0.04, 0.78, 0.04, M.frame);
    p.position.set(sx, 1.155, -0.375);
    frameGroup.add(p);
  }
  for (const sz of [-1, 1]) {
    const b = box(1.1, 0.04, 0.04, M.frame); b.position.set(0, 1.14, sz * 0.375);
    frameGroup.add(b);
  }
  for (const sx of [-1, 1]) {
    const b = box(0.04, 0.04, 0.66, M.frame); b.position.set(sx * 0.575, 1.14, 0);
    frameGroup.add(b);
  }
  // 网孔板（左右后三面）
  const holeTex = makeHoleTexture();
  const meshMat = new THREE.MeshStandardMaterial({
    map: holeTex, color: 0xffffff, metalness: 0.55, roughness: 0.5,
    side: THREE.DoubleSide
  });
  const sideL = box(0.012, 0.76, 0.7, meshMat); sideL.position.set(-0.575, 1.165, 0);
  const sideR = box(0.012, 0.76, 0.7, meshMat); sideR.position.set(0.575, 1.165, 0);
  const back = box(1.08, 0.76, 0.012, meshMat); back.position.set(0, 1.165, -0.375);
  frameGroup.add(sideL, sideR, back);
}
scene.add(frameGroup);
registerPart('frame', frameGroup, {
  code: '01',
  kind: '结构件 / 钣金',
  name: '围框骨架与底柜',
  brief: '钣金立柱、横梁与网孔板组成安全围框，防止运动部件越界；底柜集成供电与控制器件，底部福马轮可推行、踩下即固定。',
  specs: [
    ['材质', '2.0 mm SPCC 冷轧钢板'],
    ['表面处理', '亚光黑 3155-PEB 静电喷塑'],
    ['立柱', '四角立柱 4 根 / 中间立柱 5 根'],
    ['台面', '2080 工业铝型材（自带安装槽）'],
    ['移动脚轮', 'GD-80F 福马轮'],
    ['外形尺寸', '1200 × 800 × 1570 mm'],
  ],
  points: ['钣金立柱与横梁：2.0 毫米冷轧板，围出安全工作区', '网孔板：既能观察内部运行，又起到防护作用', '型材台面：2080 工业铝型材，自带安装槽', '福马轮：整机可移动，锁下即固定'],
  role: '结构件：整机骨架与安全防护。'
});

/* ---- ABB 控制柜 ---- */
const cabinetGroup = new THREE.Group();
const cabLeds = [];
{
  const c = box(0.3, 0.46, 0.4, M.base); c.position.set(0, 0.45, 0.16);
  const stripe = box(0.3, 0.045, 0.012, M.armAcc); stripe.position.set(0, 0.58, 0.365);
  const badge = box(0.07, 0.02, 0.006, M.armAcc); badge.position.set(0.09, 0.52, 0.366);
  cabinetGroup.add(c, stripe, badge);
  for (let k = 0; k < 3; k++) {
    const led = box(0.014, 0.014, 0.008,
      new THREE.MeshStandardMaterial({ color: ACCENT, emissive: ACCENT, emissiveIntensity: 0.8 }));
    led.position.set(-0.09 + k * 0.045, 0.3, 0.366);
    cabLeds.push(led);
    cabinetGroup.add(led);
  }
}
scene.add(cabinetGroup);
registerPart('cabinet', cabinetGroup, {
  code: '02',
  kind: '控制器件',
  name: '控制柜（主控计算平台）',
  brief: '底柜里的主控机柜：图纸上的 ABB 控制柜支架与前封板围出安装空间，里面放主控计算平台与供电模块，机械臂控制、相机采集和语音流程都跑在这上面。',
  specs: [
    ['计算平台', 'Xavier NX labbox（Jetson Xavier NX）'],
    ['安装空间', '底柜内部，前置检修门'],
    ['供电', '整机供电分配 + 各模块 5V/12V 输出'],
    ['对外接口', 'USB 相机 / 串口（云台）/ 以太网'],
    ['配套钣金', 'ABB 控制柜支架、ABB 前封板'],
  ],
  points: ['跑机械臂控制、视觉识别与语音调度的主程序', '为机械臂、相机、主控板提供稳定供电', '前面板左右封板，中间留检修与散热空间'],
  role: '控制核心：整机的计算、供电与接口中枢。'
});

/* ---- 显示屏 ---- */
function makeDisplay() {
  const c = document.createElement('canvas');
  c.width = 512; c.height = 300;
  const g = c.getContext('2d');
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  function draw(title, sub) {
    const bg = g.createLinearGradient(0, 0, 0, 300);
    bg.addColorStop(0, '#0d141d'); bg.addColorStop(1, '#141d28');
    g.fillStyle = bg; g.fillRect(0, 0, 512, 300);
    g.fillStyle = '#3b7de0'; g.fillRect(0, 0, 512, 6);
    g.fillStyle = '#1f2b3a'; g.fillRect(24, 40, 464, 1);
    g.font = 'bold 44px "Noto Sans SC","Microsoft YaHei",sans-serif';
    g.fillStyle = '#eef4fb'; g.fillText(title, 28, 96);
    g.font = '30px "Noto Sans SC","Microsoft YaHei",sans-serif';
    g.fillStyle = '#7fb0f5'; g.fillText(sub, 28, 160);
    g.font = '22px "Noto Sans SC","Microsoft YaHei",sans-serif';
    g.fillStyle = '#55697e'; g.fillText('YL-293H 人工智能综合实验箱', 28, 246);
    const colors = ['#3b7de0', '#34d399', '#f0a94c'];
    for (let k = 0; k < 3; k++) {
      g.beginPath(); g.arc(430 + k * 22, 246, 6, 0, Math.PI * 2);
      g.fillStyle = colors[k]; g.fill();
    }
    tex.needsUpdate = true;
  }
  draw('待机姿态就绪', '等待下一口令…');
  return { tex, draw };
}
const display = makeDisplay();
const screenGroup = new THREE.Group();
{
  /* 以屏幕自身中心为原点搭建零件，再整体平移到围框内侧后壁前。
     以前是把零件写在世界坐标上、再让整个组绕世界原点旋转，
     结果屏幕被甩到 x≈-0.43 / z≈-0.17，插进了左侧壁里。
     现在贴着后壁居中安装，两侧立柱（x=±0.29）与中部横梁都不干涉。 */
  const hanger = box(0.026, 0.10, 0.026, M.frame);
  hanger.position.set(0, 0.17, -0.003);
  const bezel = box(0.36, 0.24, 0.022, M.base);
  const panelMat = new THREE.MeshBasicMaterial({ map: display.tex });
  const panel = new THREE.Mesh(new THREE.PlaneGeometry(0.335, 0.215), panelMat);
  panel.position.z = 0.012;
  screenGroup.add(hanger, bezel, panel);
  screenGroup.position.set(0, 1.31, -0.352);
}
scene.add(screenGroup);
registerPart('screen', screenGroup, {
  code: '03',
  kind: '人机界面',
  name: '显示屏',
  brief: '实时显示运行状态：正在听指令、正在识别、已锁定目标、任务完成等，让整个流程看得见。',
  specs: [
    ['安装方式', '围框后壁悬挂，面向操作者'],
    ['显示内容', '运行状态与阶段提示'],
    ['配套钣金', '显示器安装板'],
  ],
  points: ['挂在围框后部，面向操作者', '同步显示语音、视觉、运动各阶段状态'],
  role: '人机界面：演示过程可视化。'
});

function setScreen(title, sub) {
  display.draw(title, sub);
  document.getElementById('screenMirror').innerHTML = title + '<br>' + sub;
}

/* ---- 云台深度相机（Orbbec DaBai DCW）----
   真实设备是装在两轴云台上的深度相机：水平可左右转、俯仰可上下摆，
   不是固定在立杆上。所以这里做成「立杆 + 云台底座 + 俯仰头」三级结构。 */
const CAM_POS = new THREE.Vector3(-0.245, TABLE_TOP, -0.26);
const CAM_YAW = 0.62;            // 云台水平：朝向工作区
const CAM_PITCH = -0.52;         // 云台俯仰：略向下看台面
const depthGroup = new THREE.Group();
let camPan, camTilt, camHead;
{
  const pole = cyl(0.014, 0.016, 0.545, M.aluDark);
  pole.position.set(CAM_POS.x, TABLE_TOP + 0.2725, CAM_POS.z);

  camPan = new THREE.Group();                       // 云台底座（绕竖轴左右转）
  camPan.position.set(CAM_POS.x, TABLE_TOP + 0.545, CAM_POS.z);
  const turret = cyl(0.026, 0.03, 0.022, M.armBody);
  const yokeL = box(0.008, 0.05, 0.012, M.aluDark); yokeL.position.set(-0.062, 0.028, 0);
  const yokeR = box(0.008, 0.05, 0.012, M.aluDark); yokeR.position.set(0.062, 0.028, 0);
  const tiltHub = cyl(0.011, 0.011, 0.03, M.armAcc, 14);
  tiltHub.rotation.z = Math.PI / 2; tiltHub.position.y = 0.05;
  camPan.add(turret, yokeL, yokeR, tiltHub);

  camTilt = new THREE.Group();                      // 俯仰轴
  camTilt.position.y = 0.05;
  camHead = new THREE.Group();                      // 相机本体（镜头朝 +Z）
  const housing = box(0.115, 0.045, 0.052, M.armBody);
  const lensRgb = cyl(0.016, 0.016, 0.022, new THREE.MeshStandardMaterial({ color: 0x0e2b4a, metalness: 0.7, roughness: 0.2 }));
  lensRgb.rotation.x = Math.PI / 2; lensRgb.position.set(-0.026, 0, 0.028);
  const lensIr = cyl(0.014, 0.014, 0.02, M.chip);
  lensIr.rotation.x = Math.PI / 2; lensIr.position.set(0.022, 0, 0.028);
  const led = box(0.014, 0.006, 0.01, new THREE.MeshStandardMaterial({ color: ACCENT2, emissive: ACCENT2, emissiveIntensity: 1 }));
  led.position.set(0.05, 0.016, 0.02);
  camHead.add(housing, lensRgb, lensIr, led);
  camTilt.add(camHead);

  camPan.rotation.y = CAM_YAW;
  camTilt.rotation.x = CAM_PITCH;
  depthGroup.add(pole, camPan);
}
scene.add(depthGroup);
registerPart('depthcam', depthGroup, {
  code: '04',
  kind: '感知单元',
  name: '云台深度相机（Orbbec DaBai DCW）',
  brief: '装在两轴云台上的深度相机：深度模组给出每个点到相机的距离，彩色模组给出画面，云台负责把镜头对准目标。系统用它做深度视觉实验（人脸测距、云台跟随）以及工作区目标的三维定位。',
  specs: [
    ['型号', 'Orbbec DaBai DCW 深度/云台相机'],
    ['输出', '彩色图 + 深度图（点云）'],
    ['云台', '水平 / 俯仰 两轴，可软件控制'],
    ['视频节点', '/dev/video0（Orbbec SDK）'],
    ['云台串口', '/dev/ttyTHS0（共享串口）'],
    ['采集帧率', 'MJPEG 25 FPS'],
    ['配套钣金', '3D 相机支架'],
  ],
  points: ['深度模组：测出每个像素的距离，得到目标三维坐标', '彩色模组：给出画面，供颜色识别与人脸检测使用', '两轴云台：把镜头对准目标，可做跟随与方向微调'],
  role: '感知单元：负责深度测量与目标三维定位。'
});

/* ---- 工作台相机（视觉分拣专用）----
   与云台深度相机是两台独立设备：这台固定在围框前上梁，俯视工作区，
   专供 OpenCV 颜色识别、条码与 OCR 实验，不参与深度视觉实训。 */
const WORKCAM_POS = new THREE.Vector3(0.04, 1.455, 0.315);
const workCamGroup = new THREE.Group();
{
  const bracket = box(0.03, 0.10, 0.02, M.aluDark);
  bracket.position.set(WORKCAM_POS.x, 1.525, 0.352);
  const arm = box(0.016, 0.016, 0.05, M.aluDark);
  arm.position.set(WORKCAM_POS.x, 1.478, 0.336);
  const body = box(0.072, 0.05, 0.06, M.chip);
  body.position.copy(WORKCAM_POS);
  body.rotation.x = -0.34;                       // 俯视工作区
  const lens = cyl(0.013, 0.013, 0.016, M.silver, 18);
  lens.position.set(WORKCAM_POS.x, WORKCAM_POS.y - 0.018, WORKCAM_POS.z + 0.028);
  lens.rotation.x = Math.PI / 2 - 0.34;
  const ring = cyl(0.017, 0.017, 0.004, M.armAcc, 18);
  ring.position.set(WORKCAM_POS.x, WORKCAM_POS.y - 0.016, WORKCAM_POS.z + 0.024);
  ring.rotation.x = Math.PI / 2 - 0.34;
  const led = box(0.012, 0.005, 0.008, new THREE.MeshStandardMaterial({ color: ACCENT2, emissive: ACCENT2, emissiveIntensity: 0.9 }));
  led.position.set(WORKCAM_POS.x + 0.026, WORKCAM_POS.y + 0.01, WORKCAM_POS.z + 0.026);
  workCamGroup.add(bracket, arm, body, lens, ring, led);
}
scene.add(workCamGroup);
registerPart('workcam', workCamGroup, {
  code: '05',
  kind: '感知单元',
  name: '工作台相机',
  brief: '固定在围框前上梁、俯视工作区的一台 USB 相机。实训里由它拍摄台面，用 OpenCV 做颜色分割与连通域分析，判断方块颜色；条码、二维码与 OCR 实验也走这台相机。',
  specs: [
    ['用途', '工作区颜色识别 / 条码二维码 / OCR'],
    ['安装', '围框前上梁固定，俯视工作区'],
    ['识别方法', 'OpenCV HSV 分割 + 连通域分析'],
    ['识别规则', '黄→1 号区，红→2 号区，绿→3 号区，蓝→4 号区'],
    ['接口', 'USB（工作区相机）'],
  ],
  points: ['俯视拍摄，视场覆盖取料区与分类放置区', '在机械臂进入工作区前完成稳定颜色识别', '识别不可靠时停止流程，避免放错位置'],
  role: '感知单元：为分拣提供颜色识别结果。'
});

/* ---- 扫描光锥 ---- */
const coneGroup = new THREE.Group();
{
  const geo = new THREE.ConeGeometry(0.055, 1, 24, 1, true);
  geo.rotateX(-Math.PI / 2);
  geo.translate(0, 0, 0.5);
  const mat = new THREE.MeshBasicMaterial({
    color: 0x3b7de0, transparent: true, opacity: 0.2,
    depthWrite: false, side: THREE.DoubleSide
  });
  const cone = new THREE.Mesh(geo, mat);
  coneGroup.add(cone);
  coneGroup.visible = false;
  scene.add(coneGroup);
}

/* ---- ESP32 主控板 ---- */
const espGroup = new THREE.Group();
{
  const acry = box(0.17, 0.006, 0.13, new THREE.MeshStandardMaterial({
    color: 0x9fd8ff, metalness: 0.1, roughness: 0.15, transparent: true, opacity: 0.35
  }));
  const pcb = box(0.13, 0.004, 0.09, M.pcb); pcb.position.y = 0.014;
  const module = box(0.05, 0.009, 0.045, M.chip); module.position.set(0, 0.021, -0.012);
  const chip1 = box(0.022, 0.006, 0.022, M.silver); chip1.position.set(-0.036, 0.019, 0.02);
  const chip2 = box(0.014, 0.005, 0.014, M.chip); chip2.position.set(0.015, 0.018, 0.025);
  const usb = box(0.016, 0.01, 0.012, M.silver); usb.position.set(0.06, 0.019, -0.028);
  const pinL = box(0.12, 0.007, 0.006, new THREE.MeshStandardMaterial({ color: 0xc9a23f, metalness: 0.9, roughness: 0.3 }));
  pinL.position.set(0, 0.017, 0.04);
  const pinR = pinL.clone(); pinR.position.set(0, 0.017, -0.04);
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const so = cyl(0.004, 0.004, 0.012, M.silver, 8);
    so.position.set(sx * 0.076, 0.006, sz * 0.054);
    espGroup.add(so);
  }
  espGroup.add(acry, pcb, module, chip1, chip2, usb, pinL, pinR);
  espGroup.position.set(-0.42, TABLE_TOP, 0.05);
}
scene.add(espGroup);
registerPart('esp', espGroup, {
  code: '06',
  kind: '控制核心',
  name: 'NodeMCU-32S 主控板',
  brief: '嵌入式传感器实验的主控板。跑 ESP32 固件，用 GPIO 直接驱动蜂鸣器、读取按键与传感器，再通过串口与上位机通信，是"传感—控制—通信"这条链路的落地点。',
  specs: [
    ['型号', 'NodeMCU ESP32S'],
    ['串口', '/dev/ttyUSB0 · 115200'],
    ['PWM 输出', 'GPIO 18 · 2000 Hz（无源蜂鸣器）'],
    ['数字输入', '按键（硬件消抖）'],
    ['固件方式', 'ESP32 基础固件烧录 + REPL 环境'],
    ['配套钣金', '主板安装板、主板压板'],
  ],
  points: ['PWM 驱动无源蜂鸣器，按频率发声', 'GPIO 读取按键与传感器信号', '串口与上位机通信，上传采集数据'],
  role: '控制核心：嵌入式传感器与执行器实验的落地点。'
});

/* ---- 语音模块 ---- */
const voiceGroup = new THREE.Group();
let voiceRing;
{
  const pcb = box(0.11, 0.004, 0.08, M.pcb); pcb.position.y = 0.012;
  const speaker = cyl(0.03, 0.03, 0.018, M.chip); speaker.position.set(-0.02, 0.023, 0);
  voiceRing = new THREE.Mesh(
    new THREE.TorusGeometry(0.034, 0.0035, 10, 40),
    new THREE.MeshStandardMaterial({ color: ACCENT, emissive: ACCENT, emissiveIntensity: 0.08 })
  );
  voiceRing.rotation.x = Math.PI / 2;
  voiceRing.position.set(-0.02, 0.033, 0);
  const mic = cyl(0.006, 0.006, 0.004, M.rubber, 12); mic.position.set(0.04, 0.015, 0.024);
  const led = box(0.01, 0.006, 0.008, new THREE.MeshStandardMaterial({ color: ACCENT2, emissive: ACCENT2, emissiveIntensity: 0.6 }));
  led.position.set(0.04, 0.015, -0.02);
  voiceGroup.add(pcb, speaker, voiceRing, mic, led);
  voiceGroup.position.set(-0.42, TABLE_TOP, 0.30);
}
scene.add(voiceGroup);
registerPart('voice', voiceGroup, {
  code: '07',
  kind: '感知单元',
  name: '语音阵列',
  brief: '低成本语音入口：用本机语音阵列录入并匹配固定口令，口令只映射到白名单动作，不直接生成舵机角度——没听清、置信度低或口令不在白名单时一律不动作。',
  specs: [
    ['输入', '本机语音阵列（麦克风阵列）'],
    ['识别方式', '本地模板匹配（录入 → 匹配）'],
    ['抓取口令', '开始抓取 / 抓取方块 / 执行抓取'],
    ['待机口令', '回到待机 / 机械臂复位 / 回原点'],
    ['停止口令', '停止 / 取消 / 不要动'],
    ['安全策略', '口令仅映射白名单动作，低置信度不动作'],
  ],
  points: ['本地录入模板，再说一次即可匹配识别', '口令归一化为 run_visual_grasp / ready / safe_noop', '识别不通过就保持不动，不做危险动作'],
  role: '交互入口：把现场口令转成受控的白名单动作。'
});

/* ---- 机械臂 ---- */
const ARM = { x: 0.30, z: -0.10, L1: 0.26, L2: 0.24, Lg: 0.08, shoulderY: TABLE_TOP + 0.11 };
const armGroup = new THREE.Group();
let shoulderPivot, elbowPivot, wristPivot, fingerL, fingerR, ballAnchor;
{
  armGroup.position.set(ARM.x, TABLE_TOP, ARM.z);
  const plate = box(0.11, 0.01, 0.11, M.armBody); plate.position.y = 0.005;
  const baseC = cyl(0.045, 0.05, 0.05, M.armBody); baseC.position.y = 0.03;
  const housing = box(0.09, 0.09, 0.09, M.armBody); housing.position.y = 0.065;
  armGroup.add(plate, baseC, housing);

  shoulderPivot = new THREE.Group();
  shoulderPivot.position.y = 0.11;
  const shoulderCyl = cyl(0.036, 0.036, 0.11, M.armAcc, 20);
  shoulderCyl.rotation.z = Math.PI / 2;
  const shoulderHub = cyl(0.04, 0.04, 0.022, M.armBody, 20);
  shoulderHub.rotation.z = Math.PI / 2;
  const upper = box(0.065, ARM.L1, 0.05, M.armBody);
  upper.position.y = ARM.L1 / 2;
  shoulderPivot.add(shoulderCyl, shoulderHub, upper);
  armGroup.add(shoulderPivot);

  elbowPivot = new THREE.Group();
  elbowPivot.position.y = ARM.L1;
  const elbowCyl = cyl(0.032, 0.032, 0.096, M.armAcc, 20);
  elbowCyl.rotation.z = Math.PI / 2;
  const elbowHub = cyl(0.036, 0.036, 0.02, M.armBody, 20);
  elbowHub.rotation.z = Math.PI / 2;
  const fore = box(0.05, ARM.L2, 0.04, M.armBody);
  fore.position.y = ARM.L2 / 2;
  elbowPivot.add(elbowCyl, elbowHub, fore);
  shoulderPivot.add(elbowPivot);

  wristPivot = new THREE.Group();
  wristPivot.position.y = ARM.L2;
  const wristCyl = cyl(0.022, 0.022, 0.07, M.armAcc, 16);
  wristCyl.rotation.z = Math.PI / 2;
  /* 夹爪手掌：宽度覆盖两根手指的全部行程，任何开合状态下手指都压在手掌上 */
  const gripBase = box(0.14, 0.022, 0.058, M.armBody);
  gripBase.position.y = 0.030;
  /* 每根手指由「滑块 + 指板」组成，滑块始终贴着手掌，不会出现空隙 */
  fingerL = new THREE.Group();
  fingerR = new THREE.Group();
  for (const grp of [fingerL, fingerR]) {
    const slide = box(0.026, 0.018, 0.05, M.armBody);
    slide.position.y = 0.026;
    const jaw = box(0.013, 0.055, 0.036, M.aluDark);
    jaw.position.y = 0.056;
    grp.add(slide, jaw);
  }
  fingerL.position.set(0.042, 0, 0);
  fingerR.position.set(-0.042, 0, 0);
  ballAnchor = new THREE.Object3D();
  ballAnchor.position.y = ARM.Lg;
  wristPivot.add(wristCyl, gripBase, fingerL, fingerR, ballAnchor);
  elbowPivot.add(wristPivot);
}
scene.add(armGroup);
registerPart('arm', armGroup, {
  code: '08',
  kind: '执行机构',
  name: '五自由度总线舵机机械臂',
  brief: '五个总线舵机串在一根总线上：servo0 转底座、servo1 摆大臂、servo2 折中间关节、servo3 调腕部姿态、servo4 开合夹爪。抓取时从方块正上方垂直下降夹取，抬到统一搬运高度后转运，落到对应颜色区域，再回到待机位。',
  specs: [
    ['驱动方式', '5 路总线舵机（servo0 – servo4）'],
    ['servo0', '底座回转，控制左右方向'],
    ['servo1', '大臂俯仰，角度增大向下接近台面'],
    ['servo2', '中间关节，配合腕部控制伸展与回收'],
    ['servo3', '腕部俯仰，控制夹爪姿态'],
    ['servo4', '夹爪开合，增大为张开、减小为闭合'],
    ['末端执行器', '两指平行夹爪'],
    ['待机姿态', 'servo0 89.8° / servo1 14.0° / servo2 14.8° / servo3 −118.8° / servo4 23.4°'],
    ['臂长', '大臂 260 mm · 小臂 240 mm'],
  ],
  points: ['底座回转决定抓取方向，大臂与中间关节决定到达位置', '腕部调整夹爪朝向，保证垂直下降夹取', '夹爪闭合夹紧方块，抬到统一搬运高度再转运', '动作前先确认处于待机姿态，完成后自动回待机'],
  role: '执行机构：按白名单路径完成"夹取—搬运—分类放置"。'
});

/* ---- 彩色方块与分类放置区 ----
   真实实训物料是黄 / 红 / 绿 / 蓝四种颜色的方块，对应 1–4 号分类放置区
   （黄→1 号、红→2 号、绿→3 号、蓝→4 号）；取料区摆放待取方块，
   机械臂从方块正上方垂直下降夹取，再送到对应颜色区域。 */
const CUBE_H = 0.05;
const CUBE_COLORS = { yellow: 0xe8b21f, red: 0xc9382c, green: 0x2f9e63, blue: 0x2b6fd0 };
const cubeMat = hex => new THREE.MeshStandardMaterial({
  color: hex, metalness: 0.12, roughness: 0.42, envMapIntensity: 0.7,
});
const BALL_HOME = new THREE.Vector3(0.10, TABLE_TOP + CUBE_H / 2, 0.15);
/* 4 个分类放置区（1 号黄 / 2 号红 / 3 号绿 / 4 号蓝），都落在机械臂可达范围内 */
const ZONES = [
  [-0.15, -0.05, CUBE_COLORS.yellow, '1'],
  [-0.01, -0.05, CUBE_COLORS.red, '2'],
  [-0.15,  0.09, CUBE_COLORS.green, '3'],
  [-0.01,  0.09, CUBE_COLORS.blue, '4'],
];
/* 演示搬运落点：识别为黄色 → 1 号区 */
const PAD = new THREE.Vector3(ZONES[0][0], TABLE_TOP + 0.008, ZONES[0][1]);

const ball = new THREE.Mesh(
  new THREE.BoxGeometry(CUBE_H, CUBE_H, CUBE_H),
  cubeMat(CUBE_COLORS.yellow)
);
ball.castShadow = true;
ball.receiveShadow = true;
ball.position.copy(BALL_HOME);
scene.add(ball);
registerPart('ball', ball, {
  code: '09',
  kind: '演示物料',
  name: '彩色方块（黄色）',
  brief: '本次演示被搬运的物料。相机先认出它是黄色，机械臂再从正上方垂直下降夹取，送到 1 号（黄）分类放置区。',
  specs: [
    ['物料', '彩色方块（黄 / 红 / 绿 / 蓝 四色）'],
    ['尺寸', '50 × 50 × 50 mm（示意）'],
    ['抓取方式', '从方块正上方垂直下降夹取'],
    ['去向', '按颜色送到对应编号区域'],
  ],
  points: ['颜色由工作台相机识别，不靠固定取料点对应', '必须从正上方垂直下降，避免推倒方块', '夹起后先抬到统一搬运高度再水平转运'],
  role: '被搬运对象：颜色决定它落到哪个放置区。'
});

const padGroup = new THREE.Group();
{
  const baseMat = new THREE.MeshStandardMaterial({ color: 0xf4f7fa, metalness: 0.1, roughness: 0.65 });
  for (const [zx, zz, col, no] of ZONES) {
    const disc = cyl(0.036, 0.036, 0.006, baseMat, 26);
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(0.037, 0.0038, 10, 36),
      new THREE.MeshStandardMaterial({ color: col, emissive: col, emissiveIntensity: 0.35 })
    );
    ring.rotation.x = Math.PI / 2;
    ring.position.y = 0.005;
    ring.name = 'zone' + no;
    const g = new THREE.Group();
    g.add(disc, ring);
    g.position.set(zx - PAD.x, 0 - 0.008, zz - PAD.z);   // padGroup 已整体放到 PAD 高度
    padGroup.add(g);
  }
  /* 取料区：方形标示线 + 待取的三只方块（红 / 绿 / 蓝） */
  const pickup = [[0.10, 0.15], [0.19, 0.15], [0.10, 0.25], [0.19, 0.25]];
  for (const [wx, wz] of pickup) {
    const bar = 0.10, t = 0.004, half = bar / 2;
    for (const [dx, dz, sx, sz] of [[0, -half, bar, t], [0, half, bar, t], [-half, 0, t, bar], [half, 0, t, bar]]) {
      const seg = box(sx, 0.003, sz, M.aluDark);
      seg.position.set(wx + dx - PAD.x, TABLE_TOP + 0.002 - PAD.y, wz + dz - PAD.z);
      padGroup.add(seg);
    }
  }
  for (const [wx, wz, key] of [[0.19, 0.15, 'red'], [0.10, 0.25, 'green'], [0.19, 0.25, 'blue']]) {
    const c = box(CUBE_H, CUBE_H, CUBE_H, cubeMat(CUBE_COLORS[key]));
    c.position.set(wx - PAD.x, TABLE_TOP + CUBE_H / 2 - PAD.y, wz - PAD.z);
    padGroup.add(c);
  }
  padGroup.position.copy(PAD);
}
scene.add(padGroup);
registerPart('pad', padGroup, {
  code: '10',
  kind: '工作站台',
  name: '取料区与分类放置区',
  brief: '台面上划出取料区与四个分类放置区：方块摆在取料区，识别颜色后由机械臂送到对应编号的区域；分类规则是黄→1 号、红→2 号、绿→3 号、蓝→4 号。',
  specs: [
    ['取料区', '方形标示，摆放 4 只彩色方块'],
    ['分类放置区', '4 处（1 黄 / 2 红 / 3 绿 / 4 蓝）'],
    ['标示格式', '白色圆盘 + 彩色环，环色对应方块颜色'],
    ['码垛演示', '从取料点依次取方块，叠成一竖排'],
    ['台面', '2080 工业铝型材台面'],
  ],
  points: ['颜色与区域一一对应，识别错颜色就停下不放', '取料点与放置点都事先标定成固定点位', '统一搬运高度，保证转运平稳'],
  role: '工作区：确定抓取点、放置点与分类规则。'
});

/* 扫描锁定圈（围绕小球） */
const scanRing = new THREE.Mesh(
  new THREE.TorusGeometry(0.042, 0.003, 10, 40),
  new THREE.MeshStandardMaterial({ color: ACCENT, emissive: ACCENT, emissiveIntensity: 0.9 })
);
scanRing.rotation.x = Math.PI / 2;
scanRing.position.set(BALL_HOME.x, TABLE_TOP + 0.004, BALL_HOME.z);
scanRing.visible = false;
scene.add(scanRing);

/* ================= 运动学 ================= */
function solveIK(wristTarget) {
  const dx = wristTarget.x - ARM.x;
  const dz = wristTarget.z - ARM.z;
  const dy = wristTarget.y - (TABLE_TOP + 0.11);
  const J1 = Math.atan2(dx, dz);
  let rho = Math.hypot(dx, dz);
  const maxD = ARM.L1 + ARM.L2 - 0.008;
  const d0 = Math.hypot(rho, dy);
  if (d0 > maxD) { rho *= maxD / d0; }
  const y2 = Math.min(dy, dy * (d0 > maxD ? maxD / d0 : 1));
  const D = Math.hypot(rho, y2);
  const c3 = clamp((D * D - ARM.L1 * ARM.L1 - ARM.L2 * ARM.L2) / (2 * ARM.L1 * ARM.L2), -1, 1);
  const J3 = Math.acos(c3);
  const alpha = Math.atan2(rho, y2);
  const cB = clamp((ARM.L1 * ARM.L1 + D * D - ARM.L2 * ARM.L2) / (2 * ARM.L1 * D), -1, 1);
  const beta = Math.acos(cB);
  const J2 = alpha - beta;
  const J4 = Math.PI - (J2 + J3);
  return { J1: J1 / D2R, J2: J2 / D2R, J3: J3 / D2R, J4: J4 / D2R };
}
function wristTargetFor(point, hover = 0) {
  return new THREE.Vector3(point.x, point.y + ARM.Lg + hover, point.z);
}
const POSE = {
  home:   { J1: 0, J2: 18, J3: 96, J4: -54, g: 0.5 },
  preG:   { ...solveIK(wristTargetFor(BALL_HOME, 0.13)), g: 1 },
  grasp:  { ...solveIK(wristTargetFor(BALL_HOME)),      g: 1 },
  preP:   { ...solveIK(wristTargetFor(new THREE.Vector3(PAD.x, PAD.y + 0.032, PAD.z), 0.13)), g: 0 },
  place:  { ...solveIK(wristTargetFor(new THREE.Vector3(PAD.x, PAD.y + 0.032, PAD.z))),      g: 0 },
};

/* 关节状态：目标 + 当前（平滑逼近） */
const armCur = { ...POSE.home };
const armTgt = { ...POSE.home };
function applyPose(p) {
  armGroup.rotation.y = p.J1 * D2R;
  shoulderPivot.rotation.x = p.J2 * D2R;
  elbowPivot.rotation.x = p.J3 * D2R;
  wristPivot.rotation.x = p.J4 * D2R;
  const fx = 0.042 + 0.012 * p.g;
  fingerL.position.x = fx;
  fingerR.position.x = -fx;
}
applyPose(armCur);

/* ================= 演示时间轴 ================= */
const KEYS = [
  { t: 0.0,  p: POSE.home },
  { t: 5.0,  p: POSE.home },
  { t: 7.4,  p: POSE.preG },                       // 张开，移到小球上方
  { t: 9.0,  p: POSE.grasp },                      // 下降到抓取位
  { t: 9.6,  p: { ...POSE.grasp, g: 0 } },         // 夹爪闭合夹住
  { t: 10.4, p: { ...POSE.preG, g: 0 } },          // 抬起，保持夹住
  { t: 12.0, p: { ...POSE.preP, g: 0 } },          // 平移到放置区上方
  { t: 12.9, p: { ...POSE.place, g: 0 } },         // 下降到放置位
  { t: 13.5, p: { ...POSE.place, g: 1 } },         // 张开释放
  { t: 14.4, p: { ...POSE.preP, g: 1 } },          // 抬起
  { t: 16.6, p: POSE.home },                       // 回位
];
const DEMO_END = 17.4;
function sampleTimeline(t) {
  let a = KEYS[0], b = KEYS[KEYS.length - 1];
  for (let i = 0; i < KEYS.length - 1; i++) {
    if (t >= KEYS[i].t && t <= KEYS[i + 1].t) { a = KEYS[i]; b = KEYS[i + 1]; break; }
  }
  const span = Math.max(0.0001, b.t - a.t);
  let u = clamp((t - a.t) / span, 0, 1);
  u = u * u * (3 - 2 * u);
  const out = {};
  for (const k of ['J1', 'J2', 'J3', 'J4', 'g']) {
    out[k] = a.p[k] + (b.p[k] - a.p[k]) * u;
  }
  return out;
}

/* 演示事件 */
let voiceMode = 'off';   // off | on | blink
let coneOn = false;
let ballHeld = false;
let ballDrop = null;
const demo = { active: false, t0: 0, fired: 0 };
const EVENTS = [
  { t: 0.4,  fn: () => { voiceMode = 'on'; setScreen('口令已识别', '“开始抓取” → run_visual_grasp'); setStep(1); } },
  { t: 2.6,  fn: () => { coneOn = true; scanRing.visible = true; setScreen('工作台相机识别中', 'HSV 颜色分割 · 连通域分析'); setStep(2); } },
  { t: 4.8,  fn: () => { setScreen('识别到黄色方块', '映射到 1 号（黄）放置区'); } },
  { t: 5.2,  fn: () => { coneOn = false; scanRing.visible = false; voiceMode = 'off'; setScreen('路径规划完成', '从正上方垂直下降夹取'); setStep(3); } },
  { t: 9.65, fn: () => { attachBall(); setScreen('夹爪已闭合', '已夹紧方块 · 抬到搬运高度'); setStep(4); } },
  { t: 11.6, fn: () => { setScreen('搬运中', '即将到达 1 号放置区'); } },
  { t: 13.9, fn: () => { detachBall(); } },
  { t: 14.0, fn: () => { setScreen('放置完成', '按颜色规则放下方块'); setStep(5); } },
  { t: 16.8, fn: () => { voiceMode = 'blink'; setScreen('已回到待机姿态', '等待下一条口令'); } },
  { t: 17.35,fn: () => { voiceMode = 'off'; } },
];

function attachBall() {
  ballAnchor.updateWorldMatrix(true, false);
  ballAnchor.attach(ball);
  ballHeld = true;
}
function detachBall() {
  const p = ball.getWorldPosition(new THREE.Vector3());
  scene.attach(ball);
  ballHeld = false;
  ballDrop = {
    from: p.clone(),
    to: new THREE.Vector3(PAD.x, PAD.y + 0.032, PAD.z),
    t: 0, dur: 0.22
  };
}
function resetBall() {
  scene.attach(ball);
  ball.position.copy(BALL_HOME);
  ball.rotation.set(0, 0, 0);
  ballHeld = false;
  ballDrop = null;
}

/* 流程步骤高亮 */
const stepEls = [...document.querySelectorAll('.step')];
const STEP_NAME = ['待机', '口令识别', '颜色识别', '路径规划', '垂直夹取', '分类放置'];
let curStep = 0;
function setStep(n) {
  curStep = n;
  stepEls.forEach(el => el.classList.toggle('on', Number(el.dataset.step) === n));
}

/* ================= 交互：点击 / 悬停 ================= */
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
let hoverId = null;
let downXY = null;

function pick(cx, cy) {
  pointer.x = (cx / window.innerWidth) * 2 - 1;
  pointer.y = -(cy / window.innerHeight) * 2 + 1;
  raycaster.setFromCamera(pointer, camera);
  const hits = raycaster.intersectObjects(clickableGroups, true);
  if (!hits.length) return null;
  let o = hits[0].object;
  while (o && !o.userData.partId) o = o.parent;
  return o ? o.userData.partId : null;
}

const infoCard = document.getElementById('infoCard');
const infoCode = document.getElementById('infoCode');
const infoKind = document.getElementById('infoKind');
const specTable = document.getElementById('specTable');

/* ---------- 部件聚焦：镜头运镜 + 其余虚化 ---------- */
const VIEW_HOME = { pos: new THREE.Vector3(2.4, 1.9, 3.3), tgt: new THREE.Vector3(0, 1.18, 0) };
/* 演示机位：比总览更近，让机械臂的动作看得清楚 */
const VIEW_DEMO = { pos: new THREE.Vector3(2.06, 1.78, 2.86), tgt: new THREE.Vector3(0.06, 1.0, 0.02) };

/* 正前方（正立面）：进入仿真后的工作机位，也是清空选中后的归位视角。
   机位落在设备的对称面上，只带约 7° 俯角，保证台面与操作区还能看见 */
const VIEW_FRONT = { pos: new THREE.Vector3(0, 1.22, 2.9), tgt: new THREE.Vector3(0, 0.86, 0) };

/* 视角预设：工程图纸习惯的正交视图 + 一个等轴测（前 / 侧 / 俯 / 等轴） */
const VIEW_PRESETS = {
  front: VIEW_FRONT,
  side:  { pos: new THREE.Vector3(2.9, 1.22, 0.0), tgt: new THREE.Vector3(0, 0.86, 0) },
  top:   { pos: new THREE.Vector3(0.96, 3.3, 0.96), tgt: new THREE.Vector3(0, 0.74, 0) },
  iso:   { pos: new THREE.Vector3(1.67, 2.53, 1.67), tgt: new THREE.Vector3(0, 0.86, 0) },
};
const VIEW_LABEL = { front: '正前方', side: '右侧面', top: '俯视', iso: '等轴测' };
let activeView = null;
const viewBtns = {};
function syncViews() {
  for (const k in viewBtns) viewBtns[k].classList.toggle('on', k === activeView);
}
/* 切到某个预设视角；用户自己转动视角后（controls start）会清掉高亮 */
function setView(name, dur) {
  const v = VIEW_PRESETS[name];
  if (!v) return;
  flyTo(v.pos.clone(), v.tgt.clone(), dur === undefined ? 1.05 : dur);
  activeView = name;
  syncViews();
}

/* 每个部件的观察方向（由部件指向相机），用于自动计算机位 */
const FOCUS_DIR = {
  frame:    [1.0, 0.52, 1.25],
  arm:      [0.85, 0.55, 1.0],
  depthcam: [0.45, 0.6, 1.0],
  workcam:  [0.35, 0.72, 1.0],
  esp:      [-0.6, 0.95, 0.95],
  voice:    [-0.45, 0.9, 1.0],
  screen:   [-0.25, 0.35, 1.0],
  cabinet:  [0.3, 0.42, 1.0],
  ball:     [0.35, 0.85, 1.0],
  pad:      [-0.15, 0.9, 1.0],
};
const FOCUS_ZOOM = { frame: 1.0, arm: 1.02, ball: 1.25, pad: 1.3, screen: 1.1, workcam: 1.3 };

function viewForPart(id) {
  const g = parts[id].group;
  scene.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(g);
  if (box.isEmpty()) return { pos: VIEW_HOME.pos.clone(), tgt: VIEW_HOME.tgt.clone() };
  const center = box.getCenter(new THREE.Vector3());
  const sphere = box.getBoundingSphere(new THREE.Sphere());
  const radius = Math.max(sphere.radius, 0.06);
  const halfFov = camera.fov * D2R / 2;
  const zoom = FOCUS_ZOOM[id] || 1;
  let dist = radius / Math.sin(halfFov) * 1.5 * zoom;
  dist = clamp(dist, 0.45, 3.4);
  const dir = new THREE.Vector3(...(FOCUS_DIR[id] || [0.8, 0.6, 1.0])).normalize();
  const pos = center.clone().addScaledVector(dir, dist);
  pos.y = Math.max(pos.y, 0.18);
  return { pos, tgt: center };
}

const camAnim = {
  active: false, t: 0, dur: 1.0,
  fromPos: new THREE.Vector3(), toPos: new THREE.Vector3(),
  fromTgt: new THREE.Vector3(), toTgt: new THREE.Vector3(),
};
function flyTo(pos, tgt, dur) {
  camAnim.fromPos.copy(camera.position);
  camAnim.toPos.copy(pos);
  camAnim.fromTgt.copy(controls.target);
  camAnim.toTgt.copy(tgt);
  camAnim.t = 0;
  camAnim.dur = dur === undefined ? 1.0 : dur;
  camAnim.active = true;
}
const easeInOut = u => (u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2);

/* 选中部件同时保留在背景层与主体层：背景层里它随大流一起虚化，
   主体层再以清晰版本盖在最上面，因此过渡过程中不会出现"空洞" */
function setPartLayer(id, on) {
  for (const m of parts[id].meshes) {
    if (on) m.layers.enable(1);
    else m.layers.disable(1);
  }
}

let focusedId = null;
function selectPart(id) {
  if (!parts[id]) return;
  if (demo.active) stopDemo(false);
  dismissHero();
  if (focusedId && focusedId !== id) setPartLayer(focusedId, false);
  focusedId = id;
  setPartLayer(id, true);
  blurTarget = 1;
  document.body.classList.add('focused');
  const v = viewForPart(id);
  flyTo(v.pos, v.tgt, 1.05);
  activeView = null;              // 聚焦机位不是预设视角，取消预设高亮
  syncViews();
  openInfo(id);
  syncDock();
}
/* 取消聚焦：只改状态与画面，不动镜头（供清空选中 / 切视角共用） */
function unfocus() {
  if (focusedId) {
    setPartLayer(focusedId, false);
    focusedId = null;
  }
  blurTarget = 0;
  document.body.classList.remove('focused');
  hideInfo();
  syncDock();
}
function clearSelection() {
  unfocus();
  setView('front', 0.95);         // 归位到正前方
}

function openInfo(id) {
  const d = parts[id].info;
  infoCode.textContent = d.code || '—';
  infoKind.textContent = d.kind || '部件';
  document.getElementById('infoName').textContent = d.name;
  document.getElementById('infoBrief').textContent = d.brief;
  specTable.innerHTML = (d.specs || [])
    .map(([k, v]) => '<tr><th>' + k + '</th><td>' + v + '</td></tr>').join('');
  document.getElementById('infoPoints').innerHTML = d.points.map(p => '<li>' + p + '</li>').join('');
  document.getElementById('infoRole').textContent = d.role;
  infoCard.classList.add('open');
}
function hideInfo() {
  infoCard.classList.remove('open');
}
document.getElementById('infoClose').addEventListener('click', () => clearSelection());

/* ================= 滚动叙事：图纸 → 三维 → 进入仿真 =================
   画布与图纸层都固定在窗口上，滚动位置只驱动一个进度值 p（0–1）：
   图纸逐张翻过 → 三维部件从炸开状态飞回装配 → 部件引线标注 → 进入仿真。
   ================================================================= */
const bodyEl = document.body;
let introOn = true;
const intro = { p: 0, pTarget: 0 };
const calV = new THREE.Vector3();

/* 装配动画：每个部件一个炸开方向，进入仿真前按 (1 - 装配度) 偏移 */
const EXPLODE = {
  frame:    [0, 0.9, 0],
  cabinet:  [0, -0.55, 0.2],
  screen:   [-0.35, 0.6, -0.8],
  depthcam: [-0.95, 0.4, -0.5],
  workcam:  [0.2, 1.0, 0.85],
  esp:      [-1.05, 0.25, 0.6],
  voice:    [-0.95, 0.2, 1.1],
  arm:      [0.95, 0.45, -0.3],
  ball:     [0.3, 0.8, 0.95],
  pad:      [-0.5, -0.2, 1.0],
};
const partHome = {};
for (const id in EXPLODE) {
  if (!parts[id]) continue;
  partHome[id] = {
    home: parts[id].group.position.clone(),
    dir: new THREE.Vector3(...EXPLODE[id]),
  };
}
function applyAssemble(a) {
  const k = 1 - a;
  for (const id in partHome) {
    parts[id].group.position.copy(partHome[id].home).addScaledVector(partHome[id].dir, k);
  }
}

/* 相机关键帧 */
const INTRO_KEYS = [
  { p: 0.00, pos: [0.25, 1.5, 4.9], tgt: [0, 1.05, 0.05] },
  { p: 0.28, pos: [2.1, 1.75, 3.95], tgt: [0, 1.02, 0] },
  { p: 0.52, pos: [2.75, 2.25, 4.6], tgt: [0, 0.95, 0] },
  { p: 0.76, pos: [2.05, 1.7, 3.05], tgt: [0.04, 0.95, 0.04] },
  { p: 1.00, pos: [VIEW_FRONT.pos.x, VIEW_FRONT.pos.y, VIEW_FRONT.pos.z], tgt: [0, 0.86, 0] },
];
const ramp = (p, a, b) => clamp((p - a) / (b - a), 0, 1);
function introCam(p) {
  let a = INTRO_KEYS[0], b = INTRO_KEYS[INTRO_KEYS.length - 1];
  for (let i = 0; i < INTRO_KEYS.length - 1; i++) {
    if (p >= INTRO_KEYS[i].p && p <= INTRO_KEYS[i + 1].p) { a = INTRO_KEYS[i]; b = INTRO_KEYS[i + 1]; break; }
  }
  const u = b.p === a.p ? 0 : (p - a.p) / (b.p - a.p);
  const e = u * u * (3 - 2 * u);
  camera.position.set(
    a.pos[0] + (b.pos[0] - a.pos[0]) * e,
    a.pos[1] + (b.pos[1] - a.pos[1]) * e,
    a.pos[2] + (b.pos[2] - a.pos[2]) * e
  );
  controls.target.set(
    a.tgt[0] + (b.tgt[0] - a.tgt[0]) * e,
    a.tgt[1] + (b.tgt[1] - a.tgt[1]) * e,
    a.tgt[2] + (b.tgt[2] - a.tgt[2]) * e
  );
  camera.lookAt(controls.target);
}

/* 图纸层：三张图幅按进度交叉淡入淡出，并做缓慢平移 / 推近 */
const dwEls = [...document.querySelectorAll('#drawLayer .dw')];
const genEls = [...document.querySelectorAll('#genList li')];
function applyIntro(p) {
  stageEl.style.opacity = String(ramp(p, 0.42, 0.54));

  const o0 = 1 - ramp(p, 0.10, 0.20);
  dwEls[0].style.opacity = String(o0);
  dwEls[0].style.transform = `translate(-50%,-50%) scale(${(1 + 0.05 * p).toFixed(3)})`;

  const o1 = Math.min(ramp(p, 0.10, 0.19), 1 - ramp(p, 0.32, 0.40));
  const x1 = 8 - 16 * ramp(p, 0.14, 0.38);
  dwEls[1].style.opacity = String(o1);
  dwEls[1].style.transform = `translate(calc(-50% + ${x1.toFixed(2)}vw),-50%) scale(1.04)`;

  const o2 = Math.min(ramp(p, 0.32, 0.41), 1 - ramp(p, 0.44, 0.52));
  const s2 = 1 + 0.18 * ramp(p, 0.32, 0.56);
  dwEls[2].style.opacity = String(o2);
  dwEls[2].style.transform = `translate(calc(-50% - 6vw),-50%) scale(${s2.toFixed(3)})`;

  /* 装配 + 机位 */
  applyAssemble(ramp(p, 0.46, 0.70));
  introCam(p);
  updateCallouts(p);

  /* 生成清单逐条点亮 */
  for (const li of genEls) li.classList.toggle('on', p >= Number(li.dataset.at));
}

/* 部件引线标注：圆点落在部件中心，标签按各自的偏移量错开，避免叠在一起 */
const calloutHost = document.getElementById('callouts');
const CALLOUTS = [
  { id: 'arm',      text: '五自由度总线舵机机械臂', dx: 150, dy: -74 },
  { id: 'depthcam', text: 'Orbbec 云台深度相机',    dx: -168, dy: -46 },
  { id: 'workcam',  text: '工作台相机（颜色识别）', dx: 138, dy: -6 },
  { id: 'esp',      text: 'NodeMCU-32S 主控板',     dx: -178, dy: 46 },
  { id: 'voice',    text: '语音阵列（口令白名单）', dx: -186, dy: 92 },
  { id: 'pad',      text: '取料区 / 分类放置区',    dx: 176, dy: 74 },
];
const calloutEls = CALLOUTS.filter(c => parts[c.id]).map((c, i) => {
  const el = document.createElement('div');
  el.className = 'callout';
  el.innerHTML = '<i></i><span>' + c.text + '</span>';
  calloutHost.appendChild(el);
  return { el, id: c.id, at: 0.60 + i * 0.04, dx: c.dx, dy: c.dy, box: new THREE.Box3() };
});
function updateCallouts(p) {
  const scale = Math.min(1, window.innerWidth / 1440);   // 窄屏时偏移量按比例缩小
  for (const c of calloutEls) {
    const on = p >= c.at && p < 0.92;   // 末屏"进入仿真"卡片出现时收起标注，避免压字
    c.el.classList.toggle('on', on);
    if (!on) continue;
    scene.updateMatrixWorld();
    c.box.setFromObject(parts[c.id].group);
    if (c.box.isEmpty()) continue;
    c.box.getCenter(calV).project(camera);
    c.el.style.left = ((calV.x * 0.5 + 0.5) * window.innerWidth + c.dx * scale).toFixed(0) + 'px';
    c.el.style.top = ((-calV.y * 0.5 + 0.5) * window.innerHeight + c.dy * scale).toFixed(0) + 'px';
  }
}

/* 每屏文案的淡入淡出 + 轻微视差 */
const secEls = [...document.querySelectorAll('#story .sec')];
let secMids = [];
function measureSections() {
  const vh = window.innerHeight;
  secMids = secEls.map(s => s.offsetTop + s.offsetHeight / 2 - vh / 2);
}
function applySectionFade() {
  const vh = window.innerHeight;
  const last = secEls.length - 1;
  for (let i = 0; i < secEls.length; i++) {
    /* 首屏与末屏不做淡出：它们在滚动两端本来就只露一半，
       按"居中才全亮"的规则会被判成不可见 */
    if (i === 0 || i === last) { secEls[i].style.opacity = '1'; continue; }
    const c = (window.scrollY - secMids[i]) / vh;      // 0 = 该屏居中
    const a = clamp(1 - Math.abs(c) * 1.7, 0, 1);
    secEls[i].style.opacity = a.toFixed(3);
    secEls[i].style.transform = `translateY(${(-c * 24).toFixed(1)}px)`;
  }
}
function updateIntroTarget() {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  intro.pTarget = max > 0 ? clamp(window.scrollY / max, 0, 1) : 0;
  applySectionFade();
}

/* 收起叙事、进入仿真模式 */
function dismissHero() {
  if (!introOn) { bodyEl.classList.add('ready'); return; }
  introOn = false;
  intro.p = intro.pTarget = 1;
  applyAssemble(1);
  bodyEl.classList.remove('intro');
  bodyEl.classList.add('sim', 'ready');
  stageEl.style.opacity = '';
  controls.enabled = true;
  window.scrollTo(0, 0);
}
/* 进入仿真：收起叙事，同时把镜头转到正前方（工作机位） */
function enterSim() {
  dismissHero();
  setView('front', 1.25);
}
document.getElementById('btnStart').addEventListener('click', enterSim);
document.getElementById('btnHeroDemo').addEventListener('click', () => { dismissHero(); startDemo(); });
window.addEventListener('scroll', () => { updateIntroTarget(); }, { passive: true });
window.addEventListener('resize', () => {
  updateIntroTarget();
  measureSections();
});
/* 深链：?intro=0.5 直接跳到叙事的某个进度（分享 / 截图 / 展厅循环用） */
{
  const q = new URLSearchParams(location.search);
  const jp = parseFloat(q.get('intro'));
  if (!Number.isNaN(jp)) {
    requestAnimationFrame(() => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      window.scrollTo(0, clamp(jp, 0, 1) * max);
      updateIntroTarget();
      intro.p = intro.pTarget;
      applyIntro(intro.p);
    });
  }
}

/* ---------- 底部部件导航 ---------- */
const dockEl = document.getElementById('dock');
const DOCK_ORDER = ['frame', 'cabinet', 'screen', 'depthcam', 'workcam', 'esp', 'voice', 'arm', 'ball', 'pad'];
const DOCK_LABEL = {
  frame: '整机结构', arm: '机械臂', depthcam: '深度相机', workcam: '工作台相机', esp: '主控板',
  voice: '语音阵列', screen: '显示屏', cabinet: '控制柜', ball: '彩色方块', pad: '放置区',
};
const dockBtns = {};
DOCK_ORDER.forEach(id => {
  if (!parts[id]) return;
  const b = document.createElement('button');
  b.innerHTML = '<i>' + (parts[id].info.code || '') + '</i><span>' + (DOCK_LABEL[id] || id) + '</span>';
  b.title = parts[id].info.name;
  b.addEventListener('click', () => {
    if (focusedId === id) clearSelection();
    else selectPart(id);
  });
  dockEl.appendChild(b);
  dockBtns[id] = b;
});
function syncDock() {
  for (const id in dockBtns) dockBtns[id].classList.toggle('on', id === focusedId);
}
syncDock();

/* ---------- 视角预设栏（前视 / 侧视 / 俯视 / 等轴） ---------- */
{
  const viewsEl = document.getElementById('views');
  for (const b of viewsEl.querySelectorAll('button[data-view]')) {
    const k = b.dataset.view;
    viewBtns[k] = b;
    b.addEventListener('click', () => {
      unfocus();                 // 切视角即回到整机总览，避免"虚化着半台设备"的怪状态
      setView(k);
    });
  }
  syncViews();
}
/* 数字键 1–4 快捷切视角（输入框内不响应） */
window.addEventListener('keydown', e => {
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  const tag = e.target && e.target.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
  const k = { '1': 'front', '2': 'side', '3': 'top', '4': 'iso' }[e.key];
  if (!k) return;
  if (!document.body.classList.contains('ready')) dismissHero();
  unfocus();
  setView(k);
});

/* ---------- 图纸册：13 张图幅（数据由 DXF 标题栏属性直接导出） ---------- */
const SHEETS = [
  { i: 1,  part: '显视器安装板', qty: '1 PCS', mat: '焊接图' },
  { i: 2,  part: '显视器安装板', qty: '1 PCS', mat: '2.0 mm SPCC' },
  { i: 3,  part: '侧面支架',     qty: '2 PCS', mat: '2.0 mm SPCC' },
  { i: 4,  part: '显视器安装板', qty: '1 PCS', mat: 'SPCC' },
  { i: 5,  part: '支架',         qty: '2 PCS', mat: '2.0 mm SPCC' },
  { i: 6,  part: '模块安装板',   qty: '1 PCS', mat: '2.0 mm SPCC' },
  { i: 7,  part: '摄像头支架',   qty: '1 PCS', mat: '2.0 mm SPCC' },
  { i: 8,  part: '固定座',       qty: '1 PCS', mat: '2.0 mm SPCC' },
  { i: 9,  part: '3D 相机支架',  qty: '1 PCS', mat: '2.0 mm SPCC' },
  { i: 10, part: '安装条（长）', qty: '4 PCS', mat: '2.0 mm SPCC' },
  { i: 11, part: '安装条（短）', qty: '2 PCS', mat: '2.0 mm SPCC' },
  { i: 12, part: '主板压板',     qty: '1 PCS', mat: '2.0 mm SPCC' },
  { i: 13, part: '主板安装板',   qty: '1 PCS', mat: '2.0 mm SPCC' },
];
SHEETS.forEach(s => { s.src = 'assets/drawing/sheets/' + String(s.i).padStart(2, '0') + '.png'; });

const drawerEl = document.getElementById('drawer');
const drGrid = document.getElementById('drGrid');
const drImg = document.getElementById('drImg');
const drCap = document.getElementById('drCap');
let drIndex = 0;
SHEETS.forEach((s, k) => {
  const b = document.createElement('button');
  b.className = 'dr-item';
  b.innerHTML =
    '<span class="dr-no">' + String(s.i).padStart(2, '0') + '</span>' +
    '<img src="' + s.src + '" alt="" loading="lazy">' +
    '<span class="dr-nm">' + s.part + '</span>' +
    '<span class="dr-qty">' + s.qty + '</span>';
  b.addEventListener('click', () => showSheet(k));
  drGrid.appendChild(b);
});
function showSheet(k) {
  drIndex = (k + SHEETS.length) % SHEETS.length;
  const s = SHEETS[drIndex];
  drImg.src = s.src;
  drCap.innerHTML = '<b>' + s.part + '</b>数量 ' + s.qty + ' · 材质 ' + s.mat +
    ' · 图号 YL-293H#01-B-01-2026-V1.0';
  [...drGrid.children].forEach((c, i) => c.classList.toggle('on', i === drIndex));
  setZoom(0);                       // 换图后回到适应窗口
}
/* 图纸缩放：0 适应 / 1 原始 100% / 2 放大 200% */
const drView = document.getElementById('drView');
const zoomBtns = [...drView.querySelectorAll('.dr-zoom button')];
function setZoom(z) {
  zoomBtns.forEach((b, i) => b.classList.toggle('on', i === z));
  if (!z) {
    drView.classList.remove('zoom');
    drImg.style.width = '';
    return;
  }
  drView.classList.add('zoom');
  const nw = drImg.naturalWidth || 1800;
  drImg.style.width = Math.round(nw * (z === 2 ? 2 : 1)) + 'px';
}
zoomBtns.forEach((b, i) => b.addEventListener('click', () => setZoom(i)));
drImg.addEventListener('load', () => { if (zoomBtns[0].classList.contains('on')) drImg.style.width = ''; });
function openDrawer(k) {
  drawerEl.classList.add('open');
  drawerEl.setAttribute('aria-hidden', 'false');
  document.documentElement.classList.add('dr-open');
  showSheet(k || 0);
}
function closeDrawer() {
  drawerEl.classList.remove('open');
  drawerEl.setAttribute('aria-hidden', 'true');
  document.documentElement.classList.remove('dr-open');
}
document.getElementById('drClose').addEventListener('click', closeDrawer);
drawerEl.addEventListener('click', e => { if (e.target === drawerEl) closeDrawer(); });
/* 叙事阶段打开图纸册只是叠一层，不切换模式 */
for (const b of document.querySelectorAll('.js-drawings')) {
  b.addEventListener('click', () => openDrawer(0));
}
window.addEventListener('keydown', e => {
  if (!drawerEl.classList.contains('open')) return;
  if (e.key === 'Escape') { closeDrawer(); return; }
  if (e.key === 'ArrowDown' || e.key === 'ArrowRight') { showSheet(drIndex + 1); e.preventDefault(); }
  if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') { showSheet(drIndex - 1); e.preventDefault(); }
});

/* ---------- 点击 / 悬停 ---------- */
raycaster.layers.enableAll();   // 聚焦层上的部件同样可被拾取

stageEl.addEventListener('pointerdown', e => { downXY = [e.clientX, e.clientY]; });
stageEl.addEventListener('pointerup', e => {
  if (!downXY) return;
  const moved = Math.hypot(e.clientX - downXY[0], e.clientY - downXY[1]);
  downXY = null;
  if (moved > 6) return;                        // 拖动旋转，不算点击
  if (introOn) return;                          // 叙事阶段不响应点选
  const id = pick(e.clientX, e.clientY);
  if (id) {
    if (id === focusedId) clearSelection();
    else selectPart(id);
  } else {
    clearSelection();
  }
});
let pointerMoved = false;
stageEl.addEventListener('pointermove', e => { pointerMoved = true; pointer.px = e.clientX; pointer.py = e.clientY; });

/* 用户开始手动操作视角时，中断自动运镜（并清掉预设视角的高亮） */
controls.addEventListener('start', () => {
  camAnim.active = false;
  activeView = null;
  syncViews();
});

/* 高亮管理 */
function applyGlow(id, v) {
  if (glowState[id] === v) return;
  glowState[id] = v;
  for (const m of parts[id].meshes) {
    if (m.userData.origEmissive === null) continue; // 无自发光通道的材质（如显示屏面板）跳过
    if (v <= 0) {
      m.material.emissive.setHex(m.userData.origEmissive);
      m.material.emissiveIntensity = m.userData.origEI;
    } else {
      m.material.emissive.setHex(ACCENT);
      m.material.emissiveIntensity = v;
    }
  }
}
function updateGlow() {
  for (const id in parts) {
    /* 聚焦中的部件不加任何自发光，避免出现蓝色覆盖；
       只在鼠标悬停时给一点淡淡的提示，表示可点击 */
    const v = (id === hoverId && id !== focusedId) ? 0.4 : 0;
    applyGlow(id, v);
  }
}

/* ================= 初始镜头 ================= */
/* 滚动叙事期间由进度驱动镜头，不接管鼠标；进入仿真后再交还 OrbitControls */
controls.enabled = false;
introCam(0);
measureSections();
updateIntroTarget();
applyIntro(intro.p);      // 首帧就落在正确的叙事状态，避免闪一下

/* 深链：?view=front|side|top|iso 直接切到预设视角；附加 &instant 可跳过运镜 */
{
  const q = new URLSearchParams(location.search);
  const v = q.get('view');
  if (v && VIEW_PRESETS[v]) {
    document.body.classList.add('no-fade');
    dismissHero();
    setView(v, 1.0);
    if (q.get('instant') !== null) {
      camAnim.active = false;
      camera.position.copy(camAnim.toPos);
      controls.target.copy(camAnim.toTgt);
      camera.lookAt(controls.target);
    }
  }
}

/* 深链：?part=arm 直接聚焦指定部件；附加 &instant 可跳过运镜（便于分享与自检） */
{
  const q = new URLSearchParams(location.search);
  const pid = q.get('part');
  if (pid && parts[pid]) {
    document.body.classList.add('no-fade');
    dismissHero();
    selectPart(pid);
    if (q.get('instant') !== null) {
      camAnim.active = false;
      camera.position.copy(camAnim.toPos);
      controls.target.copy(camAnim.toTgt);
      camera.lookAt(controls.target);
    }
  }
}

/* 深链：?sheet=3 直接打开图纸册并定位到第 3 张图幅（展厅 / 截图用） */
{
  const q = new URLSearchParams(location.search);
  const sn = parseInt(q.get('sheet'), 10);
  if (q.get('draw') !== null || !Number.isNaN(sn)) {
    document.body.classList.add('no-fade');
    dismissHero();
    openDrawer(Number.isNaN(sn) ? 0 : Math.max(1, Math.min(SHEETS.length, sn)) - 1);
  }
}

/* ================= 按钮 / 手动控制 ================= */
const btnDemo = document.getElementById('btnDemo');
const btnStop = document.getElementById('btnStop');
const btnReset = document.getElementById('btnReset');
const btnManual = document.getElementById('btnManual');
const manualPanel = document.getElementById('manualPanel');

/* 控制面板开关：宽屏默认常驻，窄屏默认收起 */
btnManual.addEventListener('click', () => {
  manualPanel.classList.toggle('open');
});
document.getElementById('mpClose').addEventListener('click', () => {
  manualPanel.classList.remove('open');
});
if (window.innerWidth >= 1180) manualPanel.classList.add('open');

const sliders = {
  J1: document.getElementById('rJ1'), J2: document.getElementById('rJ2'),
  J3: document.getElementById('rJ3'), J4: document.getElementById('rJ4'),
  g: document.getElementById('rG'),
};
const sliderVals = {
  J1: document.getElementById('vJ1'), J2: document.getElementById('vJ2'),
  J3: document.getElementById('vJ3'), J4: document.getElementById('vJ4'),
  g: document.getElementById('vG'),
};
const rdX = document.getElementById('rdX');
const rdY = document.getElementById('rdY');
const rdZ = document.getElementById('rdZ');
const rdStage = document.getElementById('rdStage');
const tipWorld = new THREE.Vector3();
let draggingSlider = null;

/* 面板与三维双向同步：动作进行时滑块跟着动，拖动滑块时以手为准 */
function updateReadout() {
  for (const k of ['J1', 'J2', 'J3', 'J4']) {
    if (draggingSlider !== k) sliders[k].value = armCur[k].toFixed(1);
    sliderVals[k].textContent = armCur[k].toFixed(1) + '°';
  }
  if (draggingSlider !== 'g') sliders.g.value = (armCur.g * 100).toFixed(0);
  sliderVals.g.textContent = (armCur.g * 100).toFixed(0) + '%';

  /* 夹持点坐标：以机械臂基座为原点，单位毫米 */
  ballAnchor.getWorldPosition(tipWorld);
  rdX.textContent = ((tipWorld.x - ARM.x) * 1000).toFixed(0);
  rdY.textContent = ((tipWorld.y - TABLE_TOP) * 1000).toFixed(0);
  rdZ.textContent = ((tipWorld.z - ARM.z) * 1000).toFixed(0);
  rdStage.textContent = STEP_NAME[curStep] || '待机';
}

function syncSliders() {
  for (const k in sliders) {
    const v = armCur[k];
    sliders[k].value = Math.round(k === 'g' ? v * 100 : v);
    sliderVals[k].textContent = (k === 'g' ? Math.round(v * 100) + '%' : Math.round(v) + '°');
  }
}
function setSlidersEnabled(on) {
  for (const k in sliders) sliders[k].disabled = !on;
}
for (const k in sliders) {
  sliders[k].addEventListener('pointerdown', () => { draggingSlider = k; });
  sliders[k].addEventListener('input', () => {
    if (demo.active) stopDemo(false);
    draggingSlider = k;
    const raw = Number(sliders[k].value);
    armTgt[k] = k === 'g' ? raw / 100 : raw;
    sliderVals[k].textContent = k === 'g' ? raw + '%' : raw + '°';
  });
}
window.addEventListener('pointerup', () => { draggingSlider = null; });

/* 主题切换：浅色 / 深色（大屏投影用）。优先级：网址参数 > 上次选择 > 浅色 */
const btnTheme = document.getElementById('btnTheme');
function setTheme(dark) {
  applyTheme(dark);
  btnTheme.setAttribute('aria-pressed', String(dark));
  try { localStorage.setItem('yl293h-dark', dark ? '1' : '0'); } catch (e) { /* 隐私模式下忽略 */ }
}
btnTheme.addEventListener('click', () => setTheme(!isDark));
{
  const q = new URLSearchParams(location.search);
  let dark = false;
  try { dark = localStorage.getItem('yl293h-dark') === '1'; } catch (e) { /* 隐私模式下忽略 */ }
  const forced = q.get('theme');
  if (forced === 'dark') dark = true;
  else if (forced === 'light') dark = false;
  if (dark) setTheme(true);
}

function startDemo() {
  dismissHero();
  if (focusedId) clearSelection();
  resetBall();
  demo.active = true; demo.t0 = clock.elapsedTime; demo.fired = 0;
  voiceMode = 'off'; coneOn = false; scanRing.visible = false;
  setStep(0);
  setSlidersEnabled(false);
  document.body.classList.add('demo');
  btnDemo.textContent = '演示中…';
  hideInfo();
  /* 演示时把镜头拉近到工作区，让机械臂动作看得清楚 */
  flyTo(VIEW_DEMO.pos.clone(), VIEW_DEMO.tgt.clone(), 1.1);
}
function stopDemo(armHome) {
  demo.active = false;
  voiceMode = 'off'; coneOn = false; scanRing.visible = false;
  setStep(0);
  setSlidersEnabled(true);
  document.body.classList.remove('demo');
  btnDemo.textContent = '一键演示';
  if (armHome === undefined) armHome = false;
  if (armHome) {
    Object.assign(armTgt, POSE.home);
  } else {
    Object.assign(armTgt, armCur);
  }
  syncSliders();
}
btnDemo.addEventListener('click', startDemo);
btnStop.addEventListener('click', () => stopDemo(false));
btnReset.addEventListener('click', () => {
  stopDemo(true);
  resetBall();
  setScreen('待机姿态就绪', '等待下一口令…');
});

/* ================= 主循环 ================= */
const clock = new THREE.Clock();
const tmpV1 = new THREE.Vector3();
const tmpV2 = new THREE.Vector3();

/* 深链：?demo=1 打开页面即自动演示（展厅无人值守 / 截图用）；
   附加 &instant 可跳过运镜，直接把机位放到演示机位 */
{
  const q = new URLSearchParams(location.search);
  if (q.get('demo') !== null) {
    document.body.classList.add('no-fade');
    dismissHero();
    startDemo();
    activeView = null;              // 演示机位不属于预设视角
    syncViews();
    if (q.get('instant') !== null) {
      camAnim.active = false;
      camera.position.copy(VIEW_DEMO.pos);
      controls.target.copy(VIEW_DEMO.tgt);
      camera.lookAt(controls.target);
    }
  }
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = clock.elapsedTime;

  /* 相机：滚动叙事 / 自动运镜 / 用户自由操作 */
  if (introOn) {
    intro.p += (intro.pTarget - intro.p) * Math.min(1, dt * 6);
    applyIntro(intro.p);
  } else if (camAnim.active) {
    camAnim.t += dt;
    const u = clamp(camAnim.t / camAnim.dur, 0, 1);
    const e = easeInOut(u);
    camera.position.lerpVectors(camAnim.fromPos, camAnim.toPos, e);
    controls.target.lerpVectors(camAnim.fromTgt, camAnim.toTgt, e);
    camera.lookAt(controls.target);
    if (u >= 1) camAnim.active = false;
  } else {
    controls.update();
  }

  /* 机械臂：演示或手动 */
  if (demo.active) {
    demo.t = clock.elapsedTime - demo.t0;
    const pose = sampleTimeline(demo.t);
    Object.assign(armCur, pose);   // 时间线已平滑，直接驱动
    Object.assign(armTgt, pose);
    while (demo.fired < EVENTS.length && EVENTS[demo.fired].t <= demo.t) {
      EVENTS[demo.fired].fn();
      demo.fired++;
    }
    if (demo.t >= DEMO_END) stopDemo(true);
  } else {
    const ease = 1 - Math.pow(0.001, dt); // 手动模式平滑逼近
    for (const k of ['J1', 'J2', 'J3', 'J4', 'g']) {
      armCur[k] += (armTgt[k] - armCur[k]) * ease;
    }
  }
  applyPose(armCur);
  updateReadout();

  /* 小球下落动画 */
  if (ballDrop) {
    ballDrop.t += dt;
    let u = clamp(ballDrop.t / ballDrop.dur, 0, 1);
    const arc = Math.sin(u * Math.PI) * 0.012;
    ball.position.lerpVectors(ballDrop.from, ballDrop.to, u);
    ball.position.y += arc * (1 - u);
    if (u >= 1) ballDrop = null;
  }

  /* 悬停检测（每帧一次） */
  if (pointerMoved && pointer.px !== undefined) {
    pointerMoved = false;
    const id = pick(pointer.px, pointer.py);
    hoverId = id;
    stageEl.style.cursor = id ? 'pointer' : '';
  }
  updateGlow();

  /* 虚化量平滑过渡 */
  blurAmount += (blurTarget - blurAmount) * (1 - Math.pow(0.002, dt));
  if (Math.abs(blurTarget - blurAmount) < 0.002) blurAmount = blurTarget;

  /* 语音灯环 */
  if (voiceMode === 'on') {
    voiceRing.material.emissiveIntensity = 0.55 + 0.45 * Math.sin(t * 9);
  } else if (voiceMode === 'blink') {
    voiceRing.material.emissiveIntensity = Math.sin(t * 12) > 0 ? 1.2 : 0.06;
  } else {
    voiceRing.material.emissiveIntensity = 0.08;
  }

  /* 扫描光锥 */
  if (coneOn) {
    camHead.getWorldPosition(tmpV1);
    ball.getWorldPosition(tmpV2);
    coneGroup.position.copy(tmpV1);
    coneGroup.lookAt(tmpV2);
    const d = tmpV1.distanceTo(tmpV2);
    coneGroup.scale.set(1, 1, d);
    coneGroup.children[0].material.opacity = 0.2 + 0.06 * Math.sin(t * 10);
    coneGroup.visible = true;
  } else {
    coneGroup.visible = false;
  }

  /* 云台：识别阶段左右扫视 + 轻微俯仰，说明这是两轴可动的云台相机 */
  {
    const yawT = CAM_YAW + (coneOn ? Math.sin(t * 0.9) * 0.22 : 0);
    const pitchT = CAM_PITCH + (coneOn ? Math.sin(t * 1.3) * 0.10 : 0);
    const k2 = Math.min(1, dt * 2.6);
    camPan.rotation.y += (yawT - camPan.rotation.y) * k2;
    camTilt.rotation.x += (pitchT - camTilt.rotation.x) * k2;
  }

  /* 锁定圈脉冲 */
  if (scanRing.visible) {
    scanRing.material.emissiveIntensity = 0.5 + 0.5 * Math.sin(t * 8);
    const s = 1 + 0.1 * Math.sin(t * 8);
    scanRing.scale.set(s, s, 1);
  }

  /* 控制柜指示灯 */
  for (let k = 0; k < cabLeds.length; k++) {
    cabLeds[k].material.emissiveIntensity = demo.active
      ? 0.5 + 0.5 * Math.sin(t * 6 + k * 2)
      : 0.35 + 0.15 * Math.sin(t * 2 + k);
  }

  /* ---------- 渲染 ----------
     未聚焦：直接渲染到屏幕（无额外开销）
     聚焦中：整场 → 模糊 → 合成（清晰与虚化按 blurAmount 混合）→ 选中部件单独清晰绘制 */
  if (blurAmount <= 0.001) {
    camera.layers.set(0);
    renderer.setRenderTarget(null);
    renderer.render(scene, camera);
  } else {
    camera.layers.set(0);
    renderer.setRenderTarget(rtSharp);
    renderer.render(scene, camera);

    quadMesh.material = blurMatH;
    blurMatH.uniforms.tDiffuse.value = rtSharp.texture;
    renderer.setRenderTarget(rtBlurA);
    renderer.render(quadScene, quadCam);

    quadMesh.material = blurMatV;
    blurMatV.uniforms.tDiffuse.value = rtBlurA.texture;
    renderer.setRenderTarget(rtBlurB);
    renderer.render(quadScene, quadCam);

    quadMesh.material = compositeMat;
    compositeMat.uniforms.uFocus.value = blurAmount;
    renderer.setRenderTarget(null);
    renderer.render(quadScene, quadCam);

    /* 选中部件以清晰版本盖在最上层 */
    if (focusedId && blurAmount > 0.05) {
      const bg = scene.background;
      scene.background = null;      // 主体层不画背景，否则会盖住已合成的画面
      renderer.autoClear = false;
      camera.layers.set(1);
      renderer.render(scene, camera);
      camera.layers.set(0);
      renderer.autoClear = true;
      scene.background = bg;
    }
  }
}
animate();

/* ================= 窗口自适应 ================= */
function onResize() {
  const w = window.innerWidth, h = window.innerHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);

  /* 渲染目标按设备像素尺寸重建；模糊在二分之一分辨率上进行以降低开销 */
  const db = renderer.getDrawingBufferSize(new THREE.Vector2());
  rtSharp.setSize(db.x, db.y);
  const bw = Math.max(2, Math.floor(db.x / 2));
  const bh = Math.max(2, Math.floor(db.y / 2));
  rtBlurA.setSize(bw, bh);
  rtBlurB.setSize(bw, bh);
  blurMatH.uniforms.uDir.value.set(1 / bw, 0);
  blurMatV.uniforms.uDir.value.set(0, 1 / bh);
}
window.addEventListener('resize', onResize);
onResize();
